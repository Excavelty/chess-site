import {cloneDeep} from 'lodash';
import {PieceValidator} from './MoveValidators/PieceValidator.js';
import {King} from './King.js';
import {Pawn} from './Pawn.js';

export class CheckmateControl
{
    constructor(pieces, squares)
    {
        this.pieces = pieces;
        this.squares = squares;
    }

    seeIfCheck(color, kingSquare)
    {
        let compareColor = 'white';
        if(color === 'white')
          compareColor = 'black';

        for(let i = 0; i < this.pieces.length; ++i)
        {
            if(this.pieces[i].color === compareColor)
            {
                if(this.pieces[i].checkIfCouldMove(kingSquare))
                {
                  this.addCheckColor(kingSquare);
                  let index = this.getPieceIndexBySqr(kingSquare);
                  this.pieces[index].allowCastle = false;
                  return true;
                }
            }
        }

        return false;
    }

    seeIfWouldCauseCheck(pieceIndex, kingIndex, kingColor, newSquare)//work on that
    {
        const oldSquare = this.pieces[pieceIndex].square;
        let potentialyTakenPieceIndex = this.getPieceIndexBySqr(newSquare);

        if(potentialyTakenPieceIndex !== null && this.pieces[potentialyTakenPieceIndex].color === kingColor)
        {
            return true;
        }

        if(potentialyTakenPieceIndex === null && this.pieces[pieceIndex] instanceof Pawn)
        {
            potentialyTakenPieceIndex = this.getEnPassantedPawnIfPossible(newSquare, kingColor);
            console.log(this.pieces[potentialyTakenPieceIndex]);
            //if(potentialyTakenPieceIndex !== null && this.pieces[potentialyTakenPieceIndex].allowEnPassant === false)
              //return true;
        }

        this.pieces[pieceIndex].square = newSquare;

        for(let i = 0; i < this.pieces.length; ++i)
        {
            if(kingColor !== this.pieces[i].color)
            {
                let allowEnPassantRemember = false;
                if(this.pieces[i] instanceof Pawn)
                {
                    this.pieces[i].specialTakeAllowed = true;
                }

                if(i !== potentialyTakenPieceIndex && this.pieces[i].checkIfCouldMove(this.pieces[kingIndex].square))
                {
                    this.pieces[pieceIndex].square = oldSquare;
                    if(this.pieces[i] instanceof Pawn)
                    {
                        this.pieces[i].specialTakeAllowed = false;
                        //this.pieces[i].allowEnPassant = allowEnPassantRemember;
                    }
                    return true;
                }

                if(this.pieces[i] instanceof Pawn)
                {
                    this.pieces[i].specialTakeAllowed = false;
                    //this.pieces[i].allowEnPassant = allowEnPassantRemember;
                }
            }
        }

        this.pieces[pieceIndex].square = oldSquare;
        return false;
    }

    seeIfHaveNoMove(kingIndex, kingColor)
    {
        for(let i = 0; i < this.pieces.length; ++i)
        {
            if(this.pieces[i].color === kingColor)
            {
                for(let j = 0; j < this.squares.length; ++j)
                {
                  for(let k = 0; k < this.squares.length; ++k)
                  {
                     if(this.seeIfWouldCauseCheck(i, kingIndex, kingColor, this.squares[j][k]) === false
                        && this.pieces[i].checkIfCouldMove(this.squares[j][k]))
                      {
                          return false;
                      }
                  }
                }
            }
        }

        return true;
    }

    getPieceIndexBySqr(square)
    {
        for(let i = 0; i < this.pieces.length; ++i)
        {
            if(this.pieces[i].square === square)
                return i;
        }

        return null;
    }

    getEnPassantedPawnIfPossible(square, color)
    {
        switch(color)
        {
            case 'white': {
                return this.getPieceIndexBySqr(this.squares[square.cords.cordX.charCodeAt(0) - 97][square.cords.cordY - 2]);
            } break;

            default : return this.getPieceIndexBySqr(this.squares[square.cords.cordX.charCodeAt(0) - 97][square.cords.cordY]);
        }
    }

    addCheckColor(square)
    {
        let handle = square.getSquareHandle();
        handle.style.backgroundColor = 'yellow';
    }
}
