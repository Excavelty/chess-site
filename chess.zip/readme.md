Used work: 
{
    Code snippet to flat an array: https://developer.mozilla.org/pl/docs/Web/JavaScript/Referencje/Obiekty/Array/flat#reduce_i_concat
    by https://developer.mozilla.org/pl/profiles/raszta
    Any copyright is dedicated to the Public Domain. http://creativecommons.org/publicdomain/zero/1.0/
}
